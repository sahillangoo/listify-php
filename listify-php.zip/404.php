<?php
// 404 page
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="eng">

<head>
  <title>404 Not Found</title>
</head>

<body>
  <h1>404 Not Found</h1>
  <p>The requested URL was not found on this server.</p>
</body>

</html>
